Have the:
d4c.html
d4c.png
desert.png
dojyan.mp3
flag.png
pinkUmbrell.png
simpleGame.hs (modified)
tender.png

files in the same directory. Double click the d4c html file to open it.

The example project is using my custom collision function collideDojah() to test if an object is touching two or more objects. 
Move the robot bunny into the American flags to trigger a sound effect.